from django.db import models

# Create your models here.
class Login(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    usertype=models.CharField(max_length=100)

class Parent(models.Model):
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=100) 
    last_name=models.CharField(max_length=100) 
    place=models.CharField(max_length=100)
    email=models.CharField(max_length=100) 
    phone=models.CharField(max_length=100) 
    pin=models.CharField(max_length=100)
    gender=models.CharField(max_length=100) 
     

class Teacher(models.Model):
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=100) 
    last_name=models.CharField(max_length=100) 
    place=models.CharField(max_length=100)
    email=models.CharField(max_length=100) 
    pin=models.CharField(max_length=100)
    phone=models.CharField(max_length=100) 
    gender=models.CharField(max_length=100) 
    designation=models.CharField(max_length=100) 
    post=models.CharField(max_length=100) 

class Student(models.Model):
    first_name=models.CharField(max_length=100) 
    last_name=models.CharField(max_length=100) 
    place=models.CharField(max_length=100)
    email=models.CharField(max_length=100) 
    pin=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    gender=models.CharField(max_length=100) 
    post=models.CharField(max_length=100) 


class Work(models.Model):
    TEACHER_ID=models.ForeignKey(Teacher,on_delete=models.CASCADE)
    STUDENT_ID=models.ForeignKey(Student,on_delete=models.CASCADE)
    work=models.CharField(max_length=100)
    date=models.CharField(max_length=100)

class Staff(models.Model):
    LOGIN=models.ForeignKey(Login,on_delete=models.CASCADE)  
    first_name=models.CharField(max_length=100) 
    last_name=models.CharField(max_length=100) 
    place=models.CharField(max_length=100)
    email=models.CharField(max_length=100) 
    pin=models.CharField(max_length=100)
    phone=models.CharField(max_length=100)
    gender=models.CharField(max_length=100) 
    post=models.CharField(max_length=100) 
 
class enquiry(models.Model):
    STUDENT_ID=models.ForeignKey(Student,on_delete=models.CASCADE) 
    STAFF_ID=models.ForeignKey(Staff,on_delete=models.CASCADE) 
    enquiry=models.CharField(max_length=100) 
    reply=models.CharField(max_length=100) 
    date=models.CharField(max_length=100) 


class Tutorial(models.Model): 
    STUDENTID=models.ForeignKey(Student,on_delete=models.CASCADE)   
    details=models.CharField(max_length=100) 
    date=models.CharField(max_length=100) 

class Activity(models.Model): 
    Activity=models.CharField(max_length=100) 
    videos=models.CharField(max_length=100) 
    details=models.CharField(max_length=100)     

class Question(models.Model): 
    question=models.CharField(max_length=100) 

class Answer(models.Model): 
    answer=models.CharField(max_length=100)  

class Chat(models.Model): 
    message=models.CharField(max_length=100) 
    date=models.CharField(max_length=100) 

class Complaint(models.Model): 
    PARENT=models.ForeignKey(Parent,on_delete=models.CASCADE)   
    complaint=models.CharField(max_length=100) 
    date=models.DateField(auto_now=True) 
    reply=models.CharField(max_length=100)   

class feedback(models.Model): 
    PARENT=models.ForeignKey(Parent,on_delete=models.CASCADE)   
    feedback=models.CharField(max_length=100) 
    date=models.DateField(auto_now=True) 
      

class rating(models.Model): 
    PARENT=models.ForeignKey(Parent,on_delete=models.CASCADE)   
    rating=models.CharField(max_length=100) 
    date=models.DateField(auto_now=True) 
   






