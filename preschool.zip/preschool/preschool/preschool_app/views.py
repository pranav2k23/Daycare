from urllib import request
from django.shortcuts import render,HttpResponse
from .models import *
# Create your views here.

def index(request):
    return render(request,'public/index.html')

def login(request):
    if 'submit' in request.POST:
        username = request.POST['username']
        password = request.POST['password']

        if Login.objects.filter(username=username, password=password).exists():
            q = Login.objects.get(username=username, password=password)
            request.session['login_id'] = q.pk
            login_id = request.session['login_id']
            
            if q.usertype == 'admin':
                return HttpResponse(f"<script>alert('admin login success');window.location='/admin_home'</script>")
            
            if q.usertype == 'parent':
                q1 = Parent.objects.get(LOGIN_id=login_id)
                if q1:
                    request.session['parent_id'] = q1.pk
                    return HttpResponse(f"<script>alert('user login success');window.location='/parent_home'</script>")
                else:
                    return HttpResponse(f"<script>alert('invalid login credentials');window.location='/login'</script>")
          
            if q.usertype == 'teacher':
                q1 = Teacher.objects.get(LOGIN_id=login_id)
                if q1:
                    request.session['teacher_id'] = q1.pk
                    return HttpResponse(f"<script>alert('Teacher login success');window.location='/teacher_home'</script>")
                else:
                    return HttpResponse(f"<script>alert('invalid login credentials');window.location='/login'</script>")
    return render(request,'public/login.html')
 

def parent_register(request):
    if 'submit' in request.POST:
        username=request.POST['username']
        password=request.POST['password']
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        email=request.POST['email']
        phone=request.POST['phone']
        gender=request.POST['gender']
        pin=request.POST['pin']
        place=request.POST['place']
        

        obj=Login(username=username,password=password,usertype='parent')
        obj.save()
        obj1=Parent(first_name=first_name,last_name=last_name,place=place,email=email,phone=phone,pin=pin,gender=gender,LOGIN_id=obj.pk)
        obj1.save()

    return render(request,'public/parent_register.html')

def teacher_register(request):
    if 'submit' in request.POST:
        username=request.POST['username']
        password=request.POST['password']
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        designation=request.POST['designation']
        post=request.POST['post']
        email=request.POST['email']
        phone=request.POST['phone']
        gender=request.POST['gender']
        pin=request.POST['pin']
        place=request.POST['place']

        obj=Login(username=username,password=password,usertype='teacher')
        obj.save()
        obj1=Teacher(first_name=first_name,last_name=last_name,place=place,email=email,pin=pin,phone=phone,gender=gender,designation=designation,post=post,LOGIN_id=obj.pk)
        obj1.save()
       
    # return HttpResponse(f"<script>alert('Reg successful');window.location='/teacher_register'</script>")


        
    return render(request,'public/teacher_register.html')

#admin field

def admin_home(request):
    return render(request,'admin/admin_home.html')

def view_complaint_and_reply(request):
    return render(request,'admin/view_complaint_and_reply.html')

def view_feedback(request):
    return render(request,'admin/view_feedback.html')

def view_parent(request):
    return render(request,'admin/parent.html')

def view_rating(request):
    return render(request,'admin/rating.html')

def students(request):
    return render(request,'admin/students.html')

def view_teacher(request):
    return render(request,'admin/teacher.html')

#teacher field

def addwork(request):
    return render(request,'teacher/addwork.html')

def chatwithparents(request):
    return render(request,'teacher/chatwithparents.html')

def manageactivity(request):
    return render(request,'teacher/manageactivity.html')

def manageqsandanswer(request):
    return render(request,'teacher/manageqsandanswer.html')

def sharelessons(request):
    return render(request,'teacher/sharelessons.html')

def home(request):
    return render(request,'teacher/home.html')

def viewphotoorvideo(request):
    return render(request,'teacher/viewphotoorvideo.html')

def viewuploadwork(request):
    return render(request,'teacher/viewuploadwork.html')

#parent field

def add_fees(request):
    return render(request,'parent/add_fees.html')

def add_photo_or_video(request):
    return render(request,'parent/add_photo_or_video.html')

def attend_aptitude_test(request):
    return render(request,'parent/attend_aptitude_test.html')

def chat_with_teacher(request):
    return render(request,'parent/chat_with_teacher.html')

def enquiry_and_reply(request):
    return render(request,'parent/enquiry_and_reply.html')

def manage_student(request):
    return render(request,'parent/manage_student.html')

def parent_home(request):
    return render(request,'parent/parent_home.html')

def send_complaint_and_reply(request):
    return render(request,'parent/send_complaint_and_reply.html')

def upload_work(request):
    return render(request,'parent/upload_work.html')

def view_activities(request):
    return render(request,'parent/view_activities.html')

def view_assigned_work(request):
    return render(request,'parent/view_assigned_work.html')

def view_assigned_teacher(request):
    return render(request,'parent/view_assigned_teacher.html')

def viewchat(request):
    return render(request,'parent/view_chat.html')

def view_events(request):
    return render(request,'parent/view_events.html')

def view_lessons(request):
    return render(request,'parent/view_lessons.html')

#staff field

def add_events(request):
    return render(request,'staff/add_events.html')

def add_fees(request):
    return render(request,'staff/add_fees.html')

def staff_home(request):
    return render(request,'staff/staff_home.html')

def view_enquiry_and_reply(request):
    return render(request,'parent/view_enquiry_and_reply.html')

    



